#!/bin/sh
java -cp Concorde.jar:lib/*:conf concorde.Application
